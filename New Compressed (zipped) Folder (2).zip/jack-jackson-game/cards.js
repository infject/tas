// --- Core Card Logic for Jack Jackson: Resonance Duel ---

// === Utility Functions ===
function drawCards(player, room, count = 1) {
  for (let i = 0; i < count; i++) {
    if (room.deck.length === 0) {
      if (room.discard.length === 0) break; // no cards left
      // reshuffle discard into deck
      room.deck = shuffle([...room.discard]);
      room.discard = [];
    }
    player.hand.push(room.deck.pop());
  }
}

function clamp(n, min = 0, max = 10) {
  return Math.max(min, Math.min(max, n));
}

function applyResonance(player, amount) {
  // Respect shield and avoid flags
  if (amount < 0 && player.avoidNextResonance) {
    player.avoidNextResonance = false;
    return;
  }
  player.resonance = clamp(player.resonance + amount);
}

function applyStability(player, amount) {
  // Skip next damage logic
  if (amount < 0 && player.skipNextDamage) {
    player.skipNextDamage = false;
    return;
  }
  player.stability = clamp(player.stability + amount);
  if (player.stability <= 0) player.alive = false;
}

// Shuffle helper
function shuffle(deck) {
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

// === Card Definitions ===
const cards = [
  {
    id: 1,
    name: "Echo Drain",
    type: "Spell",
    cost: 2,
    effect: "Target player loses 1 stability; gain 1 resonance",
    action: (player, target) => {
      if (!target) return;
      applyStability(target, -1);
      applyResonance(player, +1);
    }
  },
  {
    id: 2,
    name: "Layer Shift",
    type: "Spell",
    cost: 1,
    effect: "Swap resonance with another player",
    action: (player, target) => {
      if (!target) return;
      [player.resonance, target.resonance] = [target.resonance, player.resonance];
    }
  },
  {
    id: 3,
    name: "Fragment Recall",
    type: "Spell",
    cost: 1,
    effect: "Draw 2 cards",
    action: (player, _, room) => drawCards(player, room, 2)
  },
  {
    id: 4,
    name: "Overload Surge",
    type: "Spell",
    cost: 0,
    effect: "Gain 3 resonance, but lose 1 stability",
    action: (player) => {
      applyResonance(player, +3);
      applyStability(player, -1);
    }
  },
  {
    id: 5,
    name: "Timeline Lock",
    type: "Artifact",
    cost: 3,
    effect: "Prevent target from playing cards next turn",
    action: (player, target) => {
      if (target) target.locked = true;
    }
  },
  {
    id: 6,
    name: "Resonant Pulse",
    type: "Spell",
    cost: 2,
    effect: "Deal 2 resonance damage to all other players",
    action: (player, _, room) => {
      for (const pid in room.players) {
        if (pid !== player.id) applyResonance(room.players[pid], -2);
      }
    }
  },
  {
    id: 7,
    name: "Echo Shield",
    type: "Artifact",
    cost: 2,
    effect: "Gain 1 stability; absorb next resonance damage",
    action: (player) => {
      applyStability(player, +1);
      player.avoidNextResonance = true;
    }
  },
  {
    id: 8,
    name: "Dimensional Rift",
    type: "Event",
    cost: 2,
    effect: "Everyone draws 1 card, lose 1 stability",
    action: (player, _, room) => {
      for (const pid in room.players) {
        const pl = room.players[pid];
        drawCards(pl, room, 1);
        applyStability(pl, -1);
      }
    }
  },
  {
    id: 9,
    name: "Essence Vial",
    type: "Potion",
    cost: 0,
    effect: "Gain 2 resonance",
    action: (player) => applyResonance(player, +2)
  },
  {
    id: 10,
    name: "Overlapping Self",
    type: "Spell",
    cost: 3,
    effect: "Copy the last card played (except itself)",
    action: (player, _, room) => {
      if (room.table.length === 0) return;
      const lastCard = room.table[room.table.length - 1].card;
      if (lastCard.name === "Overlapping Self") return; // prevent recursion
      lastCard.action(player, null, room);
    }
  },
  {
    id: 11,
    name: "Temporal Feedback",
    type: "Spell",
    cost: 2,
    effect: "Discard a card; target discards a card",
    action: (player, target) => {
      if (player.hand.length > 0) player.hand.pop();
      if (target && target.hand.length > 0) target.hand.pop();
    }
  },
  {
    id: 12,
    name: "Fragment Merge",
    type: "Spell",
    cost: 1,
    effect: "Gain 1 stability for each resonance >3 you have",
    action: (player) => {
      if (player.resonance > 3) applyStability(player, player.resonance - 3);
    }
  },
  {
    id: 13,
    name: "Unseen Echo",
    type: "Spell",
    cost: 2,
    effect: "Steal a random card from target",
    action: (player, target) => {
      if (!target || target.hand.length === 0) return;
      const index = Math.floor(Math.random() * target.hand.length);
      const stolen = target.hand.splice(index, 1)[0];
      player.hand.push(stolen);
    }
  },
  {
    id: 14,
    name: "Reality Tear",
    type: "Event",
    cost: 3,
    effect: "Lose 2 stability; all other players gain 1 resonance",
    action: (player, _, room) => {
      applyStability(player, -2);
      for (const pid in room.players) {
        if (pid !== player.id) applyResonance(room.players[pid], +1);
      }
    }
  },
  {
    id: 15,
    name: "Anchor Stone",
    type: "Artifact",
    cost: 1,
    effect: "Prevent resonance overload once",
    action: (player) => { player.preventOverload = true; }
  },
  {
    id: 16,
    name: "Frequency Swap",
    type: "Spell",
    cost: 1,
    effect: "Exchange resonance and stability with another player",
    action: (player, target) => {
      if (!target) return;
      [player.resonance, target.resonance] = [target.resonance, player.resonance];
      [player.stability, target.stability] = [target.stability, player.stability];
    }
  },
  {
    id: 17,
    name: "Collapse",
    type: "Spell",
    cost: 3,
    effect: "Target loses all resonance, you lose 1 stability",
    action: (player, target) => {
      if (!target) return;
      target.resonance = 0;
      applyStability(player, -1);
    }
  },
  {
    id: 18,
    name: "Echo Call",
    type: "Spell",
    cost: 1,
    effect: "Draw 1 card; all players gain 1 resonance",
    action: (player, _, room) => {
      drawCards(player, room, 1);
      for (const pid in room.players) applyResonance(room.players[pid], +1);
    }
  },
  {
    id: 19,
    name: "Reflective Pulse",
    type: "Spell",
    cost: 2,
    effect: "Reflect next spell back to the caster",
    action: (player) => { player.reflectNext = true; }
  },
  {
    id: 20,
    name: "Timeless Veil",
    type: "Artifact",
    cost: 2,
    effect: "Skip damage from next event",
    action: (player) => { player.skipNextDamage = true; }
  },
  {
    id: 21,
    name: "Shattered Self",
    type: "Spell",
    cost: 2,
    effect: "Lose 2 stability; draw 3 cards",
    action: (player, _, room) => {
      applyStability(player, -2);
      drawCards(player, room, 3);
    }
  },
  {
    id: 22,
    name: "Phase Shift",
    type: "Spell",
    cost: 1,
    effect: "Avoid next resonance damage",
    action: (player) => { player.avoidNextResonance = true; }
  },
  {
    id: 23,
    name: "Residual Echo",
    type: "Spell",
    cost: 0,
    effect: "Give 1 resonance to any target",
    action: (player, target) => { if (target) applyResonance(target, +1); }
  },
  {
    id: 24,
    name: "Multiverse Insight",
    type: "Spell",
    cost: 2,
    effect: "Look at top 3 cards of any deck (placeholder)",
    action: () => {}
  },
  {
    id: 25,
    name: "Temporal Collapse",
    type: "Event",
    cost: 3,
    effect: "All players lose 1 stability, gain 2 resonance",
    action: (player, _, room) => {
      for (const pid in room.players) {
        applyStability(room.players[pid], -1);
        applyResonance(room.players[pid], +2);
      }
    }
  },
  {
    id: 26,
    name: "Rebound",
    type: "Spell",
    cost: 1,
    effect: "Return a discarded card to hand",
    action: (player, _, room) => {
      if (room.discard && room.discard.length > 0) {
        player.hand.push(room.discard.pop());
      }
    }
  },
  {
    id: 27,
    name: "Echo Trap",
    type: "Artifact",
    cost: 2,
    effect: "Target discards a card next turn",
    action: (player, target) => { if (target) target.nextDiscard = 1; }
  },
  {
    id: 28,
    name: "Layer Fusion",
    type: "Spell",
    cost: 3,
    effect: "Combine your resonance with target; gain stability = total/2",
    action: (player, target) => {
      if (!target) return;
      const total = player.resonance + target.resonance;
      applyStability(player, Math.floor(total / 2));
    }
  },
  {
    id: 29,
    name: "Dissolve",
    type: "Spell",
    cost: 2,
    effect: "Lose 1 resonance to make target lose 1 stability",
    action: (player, target) => {
      applyResonance(player, -1);
      if (target) applyStability(target, -1);
    }
  },
  {
    id: 30,
    name: "Jack’s Ascension",
    type: "Event",
    cost: 5,
    effect: "Gain 3 stability and reset resonance to 3",
    action: (player) => {
      applyStability(player, +3);
      player.resonance = 3;
    }
  }
];

module.exports = { cards, drawCards, applyResonance, applyStability, shuffle };
